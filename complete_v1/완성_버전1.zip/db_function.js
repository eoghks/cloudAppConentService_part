const { path } = require('express/lib/application');
const res = require('express/lib/response');
var db = require('./db');
var fs = require("fs");

insert_error = function (request, response, error, str) {
    msg = error.sqlMessage;
    db.query(`insert into error_log(error_date, sqlmessage, pos) values(NOW(),?, ?);`, [msg, str], function (error2, result) {
        if (error2) {
            throw error2;
        }
        /***********
        에러 테이블에 에러 처리하고 오류가 발생하였다고 클라이언트에게 전송하는 코드를 넣어주세요.==>희진씨가 해놓은 원래 코드 넣어주세요.

        ***********/
    });
}


exports.user = function (req, res, post) {
    db.query(`call check_user(?,?, ?);`, [post.user.uid, post.user.sex, post.user.age], function (error, result) {
        if (error) {
            insert_error(req, res, error, "user정보 확인");
        }
        res.redirect(307, '/cms');


    });

}


exports.cms = function (request, response, post) {
    db.query(`call UpdateCMS(?, ?);`, [post.itemName, post.user.uid], function (error, result) {
        if (error) {
            insert_error(request, response, error, "cms1");
        }
    });
    response.redirect(307, '/getPath');

}

//여기서 주석 처리된부분 처리 해주세요.
exports.getpath = function (request, response, post) {
    db.query(`select category_idx from content  where content_name=? ; `, [post.itemName], function (error1, result1) {
        if (error1) {
            insert_error(request, response, error1, "getpath part1");
            throw error1;
        }

        db.query(`select category_name from category  where category_idx=? ; `, [result1[0].category_idx], function (error2, result2) {
            if (error2) {
                insert_error(request, response, error2, "getpath part2");
                throw error2;
            }
            item = post.itemName //item명
            category = result2[0].category_name; //카테고리명
            var path = "./pdf/" + category + "/" + item + ".pdf";
            console.log(path);
            response.end(fs.readFileSync(path));
            // 소연씨가 저번 미팅 테스트시에 파일 전송하게한 코드있어요 참조해서 파일 전송되게해주세요.

        });

    });
}


exports.getItem = function (request, response) {
    db.query(`select content_name, cnt from content ; `, function (error1, result) {
        if (error1) {
            insert_error(request, response, error1, "getItem part1");
            throw error1;
        }
        var sendJosn = []
        //sendJosn.push(result[0]);
        for (let i = 0; i < result.length; i++) {
            var sendJ = {};
            sendJ.itemName = result[i].content_name;
            sendJ.count = result[i].cnt;
            sendJosn.push(sendJ);
        }
        response.json(sendJosn);

    });
}

/*
exports.getItem = function (request, response) {

    var sendJosn = [
        { itemName: 'earing', count: 10 },
        { itemName: 'neckless', count: 4 },
        { itemName: 'foundation', count: 3 },
        { itemName: 'perfume', count: 5 },
        { itemName: 'bottom', count: 12 },
        { itemName: 'top', count: 4 },
        { itemName: 'leisure', count: 14 },
        { itemName: 'outdoor', count: 16 }
    ];
    response.json(sendJosn);
}*/
