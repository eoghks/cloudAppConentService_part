const express = require('express');
var cors = require('cors');
var fs = require("fs");
var db_fun = require('./db_function');

const app = express();
const port = process.env.PORT || 3000;

//원하는 방식을 express에 추가해주어야한다.
app.use(express.json());
app.use(express.text());
app.use(cors());

/*
//post message확인
app.post('/', function (req, res) {
    console.log(req.body);      // 사용자의 JSON 요청
    res.send(req.body);    // JSON 응답
});
*/

//User확인
app.post('/user', function (req, res) {
    //console.log(req.body.user.uid);
    db_fun.user(req, res, req.body);
});

//패스얻기
app.post('/getPath', function (req, res) {
    db_fun.getpath(req, res, req.body);
});

//dCMS
app.post('/cms', function (req, res) {
    db_fun.cms(req, res, req.body);
});


//not found 구현
app.get((req, res) => {
    res.status(404).send('not found');
});
//db_front로 item,cnt json 보내주기
app.get('/getItem', (req, res) => {
    db_fun.getItem(req, res);
});

//front로 item,cnt json 보내주기 
/*
app.get('/getItem', (req, res) => {
    db_fun.getItem(req, res);
});*/

app.listen(port, () => {
    console.log("sever is listening at localhost")
});

